import random

from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
# from chat import get_response

app = Flask(__name__)

vin_list = ["3GPKHURM0RS500002" , "JHMFL5G40RX000025", "JHMFL5G40RX000056"]

# @app.get("/")
# def index_get():
#     return  render_template("base.html")

@app.post("/predict")
def predict():
    text = request.get_json().get("message")
    response = "Sorry, I am not able to understand the question."

    if "vin for" in text.lower():
        response = random.choice(vin_list)
    elif "dealer" in text.lower():
        response = "UserID: Ideal251009\nPassword:@June2024!"
    elif "origenate" in text.lower():
        response = "UserID: VAC12400\nPassword : A1234567!"
    elif "tol rule" in text.lower():
        response = "Parameter and Override level :\n<=50 then 0\n$0 - $500 – Level 2\n$500 - $1000 – Level 4\n$1000+ - Level 5"
    elif "odometer" in text.lower():
        response = "$2.0"
    elif "decision status" in text.lower():
        response = "STOPAUTOAPPR"
    elif "lsecln" in text.lower():
        response = "22%"
    elif "contract_lender_verification_2" in text.lower():
        response = "Dealer name and address incomplete on contract"
    elif "checklist item" in text.lower():
        response = "Corporate Resolution"
    elif "Formula for DTI" in text.lower():
        response = "(Application Debt + Bureau Debt – Mortgage Deduping + Loan Payment) / Income on app for all applicant and co-applicant) * 100"
    # response = get_response(text)
    message = {"answer": response}
    return jsonify(message)

if __name__ =="__main__":
    app.run(debug=True)