const hoverProperties = {
  "Self-Start": {
      imageName: "Onboarding.jpg",
      hoverTextColor: "#fff",
      bgColor: "#fff",
      titleColor: "#65c7d0",
      despColor: "#909090",
      left: "-400px",
      top: "160px",
      direction: "-1"
  },
  "Auto-Know-All": {
      imageName: "Automotive.jpg",
      hoverTextColor: "#fff",
      bgColor: "#fff",
      titleColor: "#EA3C14",
      despColor: "#909090",
      left: "-40px",
      top: "315px",
      direction: "1"
  },
  "Application-Manuals": {
      imageName: "KT.png",
      hoverTextColor: "#000",
      bgColor: "#fff",
      titleColor: "#8CC63E",
      despColor: "#909090",
      left: "-370px",
      top: "475px",
      direction: "-1"
  },
  "e-Learnings": {
      imageName: "E-learning.jpg",
      hoverTextColor: "#fff",
      bgColor: "#fff",
      titleColor: "#F99324",
      despColor: "#909090",
      left: "-150px",
      top: "633px",
      direction: "1"
  },
  "Guidelines": {
      imageName: "Testing guidelines.jpg",
      hoverTextColor: "#fff",
      bgColor: "#fff",
      titleColor: "#0071BD",
      despColor: "#909090",
      left: "-370px",
      top: "793px",
      direction: "-1"
  },
  "Tool-Kit": {
      imageName: "Testing Tools.jpg",
      hoverTextColor: "#fff",
      bgColor: "#fff",
      titleColor: "#b54b82",
      despColor: "#909090",
      left: "-180px",
      top: "945px",
      direction: "1"
  },
  "Templates": {
      imageName: "Template.jpg",
      hoverTextColor: "#fff",
      bgColor: "#fff",
      titleColor: "#c8c51b",
      despColor: "#909090",
      left: "-375px",
      top: "1110px",
      direction: "-1"
  },
  "Assessment": {
      imageName: "Assessment.jpg",
      hoverTextColor: "#fff",
      bgColor: "#fff",
      titleColor: "#18cc57",
      despColor: "#909090",
      left: "-5px",
      top: "1263px",
      direction: "1"
  }
};

let clickedTopics = [];

document.querySelectorAll('.hover-span').forEach(section => {
  // On Mouse Over
  section.addEventListener('mouseover', function() {
      const sectionId = section.getAttribute('data-id');
      const property = hoverProperties[sectionId];
      if (property) {
          // Changing Background Image
          document.body.style.backgroundImage = `url('../img/${property.imageName}')`;
          document.body.style.backgroundRepeat = 'no-repeat';
          document.body.style.backgroundPosition = 'center';
          document.body.style.backgroundSize = 'cover';
          // Changing Colors
          section.style.color = property.hoverTextColor;
          const description = document.querySelector(`p[data-id="${sectionId}"]`);
          if (description) {
              description.style.color = property.hoverTextColor;
          }
      }
  });
// On Mouse Out
  section.addEventListener('mouseout', function() {
      const sectionId = section.getAttribute('data-id');
      const property = hoverProperties[sectionId];
      if (property) {
          // Changing Background
          document.body.style.backgroundImage = 'none';
          document.body.style.backgroundColor = property.bgColor;
          // Changing Colors to Original
          section.style.color = property.titleColor;
          const description = document.querySelector(`p[data-id="${sectionId}"]`);
          if (description) {
              description.style.color = property.despColor;
          }
      }
  });

  section.addEventListener('click', function(){
    // event.preventDefault();
    const sectionId = section.getAttribute('data-id');
    const property = hoverProperties[sectionId];
   
    // Update clicked topics
    if (!clickedTopics.includes(sectionId)) {
      clickedTopics.push(sectionId);
    }

    const image = document.querySelector('.car');
    image.style.left = property.left;
    image.style.top = property.top;
    image.style.transform = 'scaleX(' + property.direction + ')';

    // Remove active and intermediate classes from all timelines
  document.querySelectorAll('.timeline').forEach(timeline => {
    timeline.classList.remove('active');
    timeline.classList.remove('intermediate');
    timeline.classList.remove('skipped');
  });

  // Add active class to the clicked timeline and intermediate class to skipped timelines
  let addIntermediateClass = false;
  document.querySelectorAll('.timeline').forEach(timeline => {
    const timelineId = timeline.querySelector('.hover-span').getAttribute('data-id');
    if (timelineId === sectionId) {
      timeline.classList.add('active');
      addIntermediateClass = false;
    } else if (addIntermediateClass) {
      timeline.classList.add('intermediate');
    } else if (timeline.classList.contains('active')) {
      addIntermediateClass = true;
    }
  });

  // Update path colors based on clicked topics
  document.querySelectorAll('.timeline').forEach(timeline => {
    const timelineId = timeline.querySelector('.hover-span').getAttribute('data-id');
    if (clickedTopics.includes(timelineId)) {
      timeline.classList.add('active');
    } else if (clickedTopics.length > 0 && !clickedTopics.includes(timelineId)) {
      timeline.classList.add('skipped');
    }
  });

    // setTimeout(() => {
    //   const link = section.closest('a');
    //   if (link) {
    //     window.open(link.href, '_blank');
    //   }
    // }, 500); // Delay of 1000 milliseconds (1 second)
  });
});

//#4c956c