//TOOLS

//Butttons to Open Tab
const toolsButton = document.getElementById('toolsButton');
//Pages
const toolsPage = document.querySelector('.toolsPage');
//Close Button 
const closeToolsTab = document.getElementById('closeToolsTab');
//Lists
const toolsCassButton = document.querySelector('.tool-cass');
const toolsNorgButton = document.querySelector('.tool-norg');
const toolsClosButton = document.querySelector('.tool-clos');
//Tabs
const toolsCASS = document.querySelector('.toolsCASS');
const toolsNORG = document.querySelector('.toolsNORG');
const toolsCLOS = document.querySelector('.toolsCLOS');
//Titles
const toolsMainH5 = document.querySelector('.toolsPage .main h5');

//FUCNTIONS
toolsButton.addEventListener('click', function(){
    toolsPage.style.display = 'block';
    toolsMainH5.textContent = 'Tools - CASS'; // Default text
});

closeToolsTab.addEventListener('click', function(){
    toolsPage.style.display = 'none';
});

toolsCassButton.addEventListener('click', function(){
    toolsCassButton.classList.add('active');
    toolsNorgButton.classList.remove('active');
    toolsClosButton.classList.remove('active');
    toolsCASS.style.display = 'flex';
    toolsNORG.style.display = 'none';
    toolsCLOS.style.display = 'none';
    toolsMainH5.textContent = 'Tools - CASS'; // Update text
});

toolsNorgButton.addEventListener('click', function(){
    toolsCassButton.classList.remove('active');
    toolsNorgButton.classList.add('active');
    toolsClosButton.classList.remove('active');
    toolsCASS.style.display = 'none';
    toolsNORG.style.display = 'flex';
    toolsCLOS.style.display = 'none';
    toolsMainH5.textContent = 'Tools - N-ORG'; // Update text
});

toolsClosButton.addEventListener('click', function(){
    toolsCassButton.classList.remove('active');
    toolsNorgButton.classList.remove('active');
    toolsClosButton.classList.add('active');
    toolsCASS.style.display = 'none';
    toolsNORG.style.display = 'none';
    toolsCLOS.style.display = 'flex';
    toolsMainH5.textContent = 'Tools - CLOS'; // Update text
});

//TEMPLATES

//Butttons to Open Tab
const templatesButton = document.getElementById('templatesButton');
//Pages
const templatesPage = document.querySelector('.templatesPage');
//Close Button 
const closeTemplatesTab = document.getElementById('closeTemplatesTab');
//Lists
const templatesCassButton = document.querySelector('.template-cass');
const templatesNorgButton = document.querySelector('.template-norg');
const templatesClosButton = document.querySelector('.template-clos');
//Tabs
const templatesCASS = document.querySelector('.templatesCASS');
const templatesNORG = document.querySelector('.templatesNORG');
const templatesCLOS = document.querySelector('.templatesCLOS');
//Titles
const templatesMainH5 = document.querySelector('.templatesPage .main h5');

//FUNCTIONS
templatesButton.addEventListener('click', function(){
    templatesPage.style.display = 'block';
    templatesMainH5.textContent = 'Templates - CASS'; // Default text
});

closeTemplatesTab.addEventListener('click', function(){
    templatesPage.style.display = 'none';
});

templatesCassButton.addEventListener('click', function(){
    templatesCassButton.classList.add('active');
    templatesNorgButton.classList.remove('active');
    templatesClosButton.classList.remove('active');
    templatesCASS.style.display = 'flex';
    templatesNORG.style.display = 'none';
    templatesCLOS.style.display = 'none';
    templatesMainH5.textContent = 'Templates - CASS'; // Update text
});

templatesNorgButton.addEventListener('click', function(){
    templatesCassButton.classList.remove('active');
    templatesNorgButton.classList.add('active');
    templatesClosButton.classList.remove('active');
    templatesCASS.style.display = 'none';
    templatesNORG.style.display = 'flex';
    templatesCLOS.style.display = 'none';
    templatesMainH5.textContent = 'Templates - N-ORG'; // Update text
});

templatesClosButton.addEventListener('click', function(){
    templatesCassButton.classList.remove('active');
    templatesNorgButton.classList.remove('active');
    templatesClosButton.classList.add('active');
    templatesCASS.style.display = 'none';
    templatesNORG.style.display = 'none';
    templatesCLOS.style.display = 'flex';
    templatesMainH5.textContent = 'Templates - CLOS'; // Update text
});

//STATUS

//Butttons to Open Tab
const statusButton = document.getElementById('statusButton');
//Pages
const statusPage = document.querySelector('.statusPage');
//Close Button 
const closeStatusTab = document.getElementById('closeStatusTab');
//Lists
const statusCassButton = document.querySelector('.status-cass');
const statusNorgButton = document.querySelector('.status-norg');
const statusClosButton = document.querySelector('.status-clos');
//Tabs
const statusCASS = document.querySelector('.statusCASS');
const statusNORG = document.querySelector('.statusNORG');
const statusCLOS = document.querySelector('.statusCLOS');

//FUNCTIONS
statusButton.addEventListener('click', function(){
    statusPage.style.display = 'block';
});

closeStatusTab.addEventListener('click', function(){
    statusPage.style.display = 'none';
});

statusCassButton.addEventListener('click', function(){
    statusCassButton.classList.add('active');
    statusNorgButton.classList.remove('active');
    statusClosButton.classList.remove('active');
    statusCASS.style.display = 'flex';
    statusNORG.style.display = 'none';
    statusCLOS.style.display = 'none';
});

statusNorgButton.addEventListener('click', function(){
    statusCassButton.classList.remove('active');
    statusNorgButton.classList.add('active');
    statusClosButton.classList.remove('active');
    statusCASS.style.display = 'none';
    statusNORG.style.display = 'flex';
    statusCLOS.style.display = 'none';
});

statusClosButton.addEventListener('click', function(){
    statusCassButton.classList.remove('active');
    statusNorgButton.classList.remove('active');
    statusClosButton.classList.add('active');
    statusCASS.style.display = 'none';
    statusNORG.style.display = 'none';
    statusCLOS.style.display = 'flex';
});

function updateProgressCircle(progress, project) {
    const circle = document.querySelector(`#progress-${project} .progress-circle`);
    const innerText = document.querySelector(`#progress-${project} .progress-circle #progress-circle-inner`);
    circle.style.background = `conic-gradient(#00202e 0% ${progress}%, #a3b7ca ${progress}% 100%)`;
    innerText.textContent = `${progress}%`;
}
updateProgressCircle(10,'cass');
updateProgressCircle(20,'norg');
updateProgressCircle(15,'clos');

//TEMPLATES

//Butttons to Open Tab
const releaseButton = document.getElementById('releaseButton');
//Pages
const releasePage = document.querySelector('.releasePage');
//Close Button 
const closeReleaseTab = document.getElementById('closeReleaseTab');
//Lists
const releaseCassButton = document.querySelector('.release-cass');
const releaseNorgButton = document.querySelector('.release-norg');
const releaseClosButton = document.querySelector('.release-clos');
//Tabs
const releaseCASS = document.querySelector('.releaseCASS');
const releaseNORG = document.querySelector('.releaseNORG');
const releaseCLOS = document.querySelector('.releaseCLOS');
//Titles
const releaseMainH5 = document.querySelector('.releasePage .main h5');

//FUNCTIONS
releaseButton.addEventListener('click', function(){
    releasePage.style.display = 'block';
    releaseMainH5.textContent = 'Releases - CASS'; // Default text
});

closeReleaseTab.addEventListener('click', function(){
    releasePage.style.display = 'none';
});

releaseCassButton.addEventListener('click', function(){
    releaseCassButton.classList.add('active');
    releaseNorgButton.classList.remove('active');
    releaseClosButton.classList.remove('active');
    releaseCASS.style.display = 'flex';
    releaseNORG.style.display = 'none';
    releaseCLOS.style.display = 'none';
    releaseMainH5.textContent = 'Releases - CASS'; // Update text
});

releaseNorgButton.addEventListener('click', function(){
    releaseCassButton.classList.remove('active');
    releaseNorgButton.classList.add('active');
    releaseClosButton.classList.remove('active');
    releaseCASS.style.display = 'none';
    releaseNORG.style.display = 'flex';
    releaseCLOS.style.display = 'none';
    releaseMainH5.textContent = 'Releases - N-ORG'; // Update text
});

releaseClosButton.addEventListener('click', function(){
    releaseCassButton.classList.remove('active');
    releaseNorgButton.classList.remove('active');
    releaseClosButton.classList.add('active');
    releaseCASS.style.display = 'none';
    releaseNORG.style.display = 'none';
    releaseCLOS.style.display = 'flex';
    releaseMainH5.textContent = 'Releases - CLOS'; // Update text
});