//Sliding Images
// var on = true;
// var myVar = setInterval(function () {
//   if (on) {
//     slides();
//   }
//   on = true;
// }, 3000);

// function slides(i) {
//   let slides = document.querySelectorAll(".slideshow div");
//   slides[0].style.width = "0px";
//   slides[1].style.width = "100%";
//   document.querySelector(".slideshow").appendChild(slides[0]);
//   if (i) {
//     on = false;
//   }
// }

// function back_slide(i) {
//   let slides = document.querySelectorAll(".slideshow div");
//   slides[0].style.width = "0px";
//   slides[slides.length - 1].style.width = "100%";
//   document.querySelector(".slideshow").insertBefore(slides[slides.length - 1], slides[0]);
//   if (i) {
//     on = false;
//   }
// }

var currentIndex = 0;
var slides = document.querySelectorAll(".slideshow .slide");
var navigation = document.createElement("div");
navigation.classList.add("navigation");
document.querySelector(".slideshow").appendChild(navigation);

// Create circles dynamically
slides.forEach((slide, index) => {
    var circle = document.createElement("div");
    circle.classList.add("circle");
    if (index === 0) {
        circle.classList.add("active");
    }
    circle.addEventListener("click", () => {
        currentIndex = index;
        showSlide(currentIndex);
    });
    navigation.appendChild(circle);
});

var circles = document.querySelectorAll(".navigation .circle");

function showSlide(index) {
    slides.forEach((slide, i) => {
        slide.style.display = i === index ? "block" : "none";
    });
    circles.forEach((circle, i) => {
        circle.classList.toggle("active", i === index);
    });
}

function nextSlide() {
    currentIndex = (currentIndex + 1) % slides.length;
    showSlide(currentIndex);
}

showSlide(currentIndex);
setInterval(nextSlide, 3000);


document.addEventListener('DOMContentLoaded', function() {
  //Adding Colors to Circle once clicked
  const links = document.querySelectorAll('.tab a');
  const clickedLinks = new Set();

  links.forEach(link => {
      link.addEventListener('click', function(event) {
          clickedLinks.add(this); // Add the clicked link to the set

          links.forEach(l => {
              if (clickedLinks.has(l)) {
                  l.querySelector('.img').style.borderColor = '#2ecc71';
              } else {
                  l.querySelector('.img').style.borderColor = '#b6042a';
              }
          });
      });
  });
});

