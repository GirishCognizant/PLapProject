document.getElementById('viewPersonalBtn').addEventListener('click', () => {    
    document.querySelector('.home').style.display = 'none';
    document.querySelector('#personalAchievement').style.display = 'block';
    document.querySelector('#teamAchievement').style.display = 'none';
});

document.getElementById('viewTeamBtn').addEventListener('click', () => {    
    document.querySelector('.home').style.display = 'none';
    document.querySelector('#personalAchievement').style.display = 'none';
    document.querySelector('#teamAchievement').style.display = 'block';
});

function goBack(){
    document.querySelector('.home').style.display = 'block';
    document.querySelector('#personalAchievement').style.display = 'none';
    document.querySelector('#teamAchievement').style.display = 'none';
}

function viewDescription(button) {
    const achievement = button.closest('.personal-achievement');
    achievement.classList.add('viewDescription');
    achievement.querySelector('#achievement-description').style.display = 'block';
    achievement.querySelector('#viewDescriptionBtn').style.display = 'none';
    achievement.querySelector('#closeDescriptionBtn').style.display = 'block';
}

function closeDescription(button) {
    const achievement = button.closest('.personal-achievement');
    achievement.classList.remove('viewDescription');
    achievement.querySelector('#achievement-description').style.display = 'none';
    achievement.querySelector('#viewDescriptionBtn').style.display = 'block';
    achievement.querySelector('#closeDescriptionBtn').style.display = 'none';
}

function viewTeamDescription(button) {
    const teamAchievement = button.closest('.team-achievement');
    teamAchievement.style.width = '600px';
    teamAchievement.querySelector('.team-achievement-summary').classList.add('viewBoth');
    teamAchievement.querySelector('.team-achievement-descirption-box').classList.add('viewBoth');
    teamAchievement.querySelector('.team-achievement-descirption-box').style.display = 'block';
    teamAchievement.querySelector('#viewTeamDescriptionBtn').style.display = 'none';
    teamAchievement.querySelector('#closeTeamDescriptionBtn').style.display = 'block';
}


function hideTeamDescription(button){
    const teamAchievement = button.closest('.team-achievement');
    teamAchievement.style.width = '350px';
    teamAchievement.querySelector('.team-achievement-summary').classList.remove('viewBoth');
    teamAchievement.querySelector('.team-achievement-descirption-box').classList.remove('viewBoth');
    teamAchievement.querySelector('.team-achievement-descirption-box').style.display = 'none';
    teamAchievement.querySelector('#viewTeamDescriptionBtn').style.display = 'block';
    teamAchievement.querySelector('#closeTeamDescriptionBtn').style.display = 'none';
}