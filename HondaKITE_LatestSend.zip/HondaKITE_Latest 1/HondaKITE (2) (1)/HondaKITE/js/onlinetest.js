async function fetchQuestions(){
  try{
    const response = await fetch('http://localhost:3000/Questions');
    const questions = await response.json();
    // console.log("Questions: ", questions);
    return questions.map(ques => ({
      question: ques.QuestionText,
      options: [ques.OptionA, ques.OptionB, ques.OptionC, ques.OptionD].filter(option => option !== null),
      correct: ques.CorrectOption

    }));
  }
  catch(err){
    console.log("Error Fetching Questions: ", err)
    return []; // Return an empty array in case of error
  }
}

let currentQuestionIndex = 0;
let questions, answers;;
const answeredQuestions = new Set();

async function startTest() {
  questions = await fetchQuestions();
  // console.log("Questions: ", questions);
  answers = Array(questions.length).fill(null);
  startTime = new Date().toISOString();
  document.querySelector('.start-page').style.display = 'none';
  document.querySelector('.question-page').style.display = 'flex';
  loadQuestion(currentQuestionIndex);
  updateProgressCircle();
  createQuestionButtons();
  document.getElementById('submit-button').disabled = true; // Disable Submit button by default
}


function updateActiveQuestionButton() {
  const questionButtons = document.querySelectorAll('.question-button');
  questionButtons.forEach((button, index) => {
    if (index === currentQuestionIndex) {
      button.classList.add('active-question');
    } else {
      button.classList.remove('active-question');
    }
  });
}

function loadQuestion(index) {
  if (!questions || questions.length === 0) {
    console.log(questions);
    console.error('Questions array is empty or undefined');
    return;
  }

  const questionContainer = document.getElementById('question-container');
  const optionsContainer = document.getElementById('options-container');
  questionContainer.innerHTML = `
    <div class="question">
        <div class="question-number">
            <p>Question ${index + 1} of ${questions.length}</p>
            <h5>${questions[index].question}</h5>
        </div>
    </div>
    `;
  optionsContainer.innerHTML = `
    <ul class="options">
        ${questions[index].options.map((option, i) => `
            <button class="option-button ${answers[index] === option ? 'selected' : ''}" onclick="selectOption(${index}, '${option}', this)"> ${option}</button>
        `).join('')}
    </ul>
    `;
  document.getElementById('next-button').style.display = index === questions.length - 1 ? 'none' : 'inline';
  document.getElementById('skip-button').style.display = index === questions.length - 1 ? 'none' : 'inline';
  document.getElementById('next-button').disabled = !answers[index];
  document.getElementById('skip-button').disabled = false; // Enable Skip button by default
  document.getElementById('back-button').style.display = index === 0 ? 'none' : 'inline';
  document.getElementById('clear-button').disabled = !answers[index]; // Disable Clear button if no answer is selected

  // Check if all questions are answered
  const allAnswered = answers.every(answer => answer !== null);
  document.getElementById('submit-button').disabled = !allAnswered; // Enable Submit button if all questions are answered
  updateActiveQuestionButton(); // Update the active question button
}

function createQuestionButtons() {
  const questionButtonsContainer = document.getElementById('question-buttons-container');
  // console.log("Button Section");
  // console.log(questions);
  questionButtonsContainer.innerHTML = questions.map((_, index) => `
   <button class="question-button" data-index="${index}" onclick="navigateToQuestion(${index})">${index + 1}</button>
    `).join('');
}


function selectOption(index, option, button) {
  if (!answers[index]) {
    answers[index] = [];
  }
  const optionIndex = answers[index].indexOf(option);
  if (optionIndex > -1) {
    answers[index].splice(optionIndex, 1);
    button.classList.remove('selected');
  } else {
    answers[index].push(option);
    button.classList.add('selected');
  }

  answeredQuestions.add(index);
  document.getElementById('next-button').disabled = answers[index].length === 0;
  document.getElementById('skip-button').disabled = true;
  document.getElementById('clear-button').disabled = answers[index].length === 0;

  // Check if all questions are answered
  const allAnswered = answers.every(answer => answer && answer.length > 0);
  document.getElementById('submit-button').disabled = !allAnswered; // Enable Submit button if all questions are answered

  updateProgressCircle();

  // Add 'answered' class to the question button
  document.querySelector(`.question-button[data-index="${index}"]`).classList.add('answered');
}

function nextQuestion() {
  currentQuestionIndex++;
  if (currentQuestionIndex < questions.length) {
    loadQuestion(currentQuestionIndex);
  }
}

function previousQuestion() {
  currentQuestionIndex--;
  if (currentQuestionIndex >= 0) {
    loadQuestion(currentQuestionIndex);
  }
}

function clearSelection() {
  // Clear the selected answer for the current question
  answers[currentQuestionIndex] = null;
  answeredQuestions.delete(currentQuestionIndex);

  // Remove 'selected' class from all option buttons
  const optionButtons = document.querySelectorAll('.option-button');
  optionButtons.forEach(btn => btn.classList.remove('selected'));

  // Disable the Next button and enable the Skip button
  document.getElementById('next-button').disabled = true;
  document.getElementById('skip-button').disabled = false;

  // Disable the Submit button if not all questions are answered
  document.getElementById('submit-button').disabled = true;

  // Remove 'answered' class from the question button
  document.querySelector(`.question-button[data-index="${currentQuestionIndex}"]`).classList.remove('answered');

  // Update the progress circle
  updateProgressCircle();
}


function skipQuestion() {
  if (answeredQuestions.has(currentQuestionIndex)) {
    answeredQuestions.delete(currentQuestionIndex);
    answers[currentQuestionIndex] = null;
    updateProgressCircle();
  }
  nextQuestion();
}

function submitTest() { 
  let score; 
  if (answers.includes(null)) {
    alert("Please answer all questions before submitting.");
  } 
  else {
    // console.log(answers)
    score = answers.reduce((acc, answer, index) => {
      let correctAnswers = questions[index].correct;

      // Ensure correctAnswers is an array
      if (!Array.isArray(correctAnswers)) {
        correctAnswers = [correctAnswers];
      }   
      
      // console.log("Questions:", questions);

      // console.log("Correct Answers:", correctAnswers);

      const isCorrect = correctAnswers.every(ans => answer.includes(ans)) && correctAnswers.length === answer.length;
      // console.log(`Question ${index + 1}: ${isCorrect ? 'Correct' : 'Incorrect'}`);
      return acc + (isCorrect ? 1 : 0);
    }, 0);

    // console.log("Final Score:");
    // console.log(score);

    endTime = new Date().toISOString();
    const userid = 1;
    fetch(`http://localhost:3000/Save-Time?userid=${userid}&score=${score}&startTime=${startTime}&endTime=${endTime}&answers=${JSON.stringify(answers)}&questions=${JSON.stringify(questions)}`)
    .then(response => response.text())
    .then(data => console.log(data))
    .catch(error => console.error('Error:', error));


    document.querySelector('.question-page').style.display = 'none';
    document.querySelector('.result-page').style.display = 'block';
    document.getElementById('result').innerText = `You scored ${score} out of ${questions.length}.`;
  }
}

function updateProgressCircle() {
  const answeredCount = answeredQuestions.size;
  const totalQuestions = questions.length;
  const progress = (answeredCount / totalQuestions) * 100;
  const progressCircleInner = document.getElementById('progress-circle-inner');
  document.querySelector('.progress-circle').style.background = `conic-gradient(#7391C8 ${progress}%, #f3f3f3 ${progress}% 100%)`;
  progressCircleInner.innerText = `${answeredCount}/${totalQuestions}`;
}

function restartTest() {
  currentQuestionIndex = 0;
  answers.fill(null);
  answeredQuestions.clear();
  document.querySelector('.result-page').style.display = 'none';
  document.querySelector('.start-page').style.display = 'block';
}


function navigateToQuestion(index) {
  currentQuestionIndex = index;
  loadQuestion(currentQuestionIndex);
}


function closeTab() {
  window.close();
}



//Admin Functions
async function viewAdmin(){
  document.querySelector('.start-page').style.display = "none";
  document.querySelector('.admin-page').style.display = "flex";
  questions = await fetchQuestions();
  displayQuestions(questions);
  
}

function displayQuestions(questions){
  const adminBody = document.querySelector('.adminBody');
  adminBody.innerHTML = ''; // Clear existing content

  questions.forEach((ques, index) => {
    const questionDiv = document.createElement('div');
    questionDiv.classList.add('adminQuestion');
    questionDiv.innerHTML = `
      <p id="adminQuNO">${index + 1}</p>
      <p id="adminQuText">${ques.question}</p>
      <div class="adminButtons">
        <button id="viewOptions" onclick="showAdminView(${index})">View</button>
        <button id="editQuestion" onclick="showAdminEdit(${index})">Edit</button>
        <button id="deleteQuestion" onclick="deleteQuestion(${index})">Delete</button>
      </div>
    `;
    adminBody.appendChild(questionDiv);
  });
}

function backToStart(){
  document.querySelector('.start-page').style.display = "flex";
  document.querySelector('.admin-page').style.display = "none";
}


//VIEW
function showAdminView(index) {
  const question = questions[index];
  document.querySelector('#viewQuestionNumber').value = `Question-${index+1}`;
  document.querySelector('#viewQuestion').value = question.question;
  
  document.querySelector('#viewOptionA').value = question.options[0];
  document.querySelector('#viewOptionB').value = question.options[1];
  const optionC = document.querySelector('#viewOptionC');
  const optionD = document.querySelector('#viewOptionD');

  optionC.value = question.options[2] || '';
  optionD.value = question.options[3] || '';

  // Hide options C and D if they are undefined
  optionC.style.display = question.options[2] ? 'block' : 'none';
  optionD.style.display = question.options[3] ? 'block' : 'none';

  document.querySelector('#viewCorrect').value = question.correct;
  document.querySelector('#viewBox').style.display = "flex";
}

function closeAdminView(){
  document.querySelector('#viewBox').style.display = "none";
}


//EDIT
async function editQuestion(){
  const questionNumberText = document.querySelector('#editQuestionNumber').value;
  const questionText = document.querySelector('#editQuestionText').value;
  const optionA = document.querySelector('#editOptionA').value;
  const optionB = document.querySelector('#editOptionB').value;
  const optionC = document.querySelector('#editOptionC').value;
  const optionD = document.querySelector('#editOptionD').value;
  const correctOption = document.querySelector('#editCorrect').value;

  // Ensure required fields are filled
  if (!questionText || !optionA || !optionB || !correctOption) {
    alert('Question, Option A, Option B, and Correct Answer are required.');
    return;
  }

  // Ensure correct answer matches one of the options
  if (![optionA, optionB, optionC, optionD].includes(correctOption)) {
    alert('Correct answer must match one of the provided options.');
    return;
  }
  // Filter Options
  const options = [optionA, optionB, optionC, optionD].filter(option => option !== '');
  const parserdId = questionNumberText.match(/\d+/);
  const id = parserdId[0];
  
  const response = await fetch(`http://localhost:3000/Edit-Question?question=${questionText}&options=${options}&correct=${correctOption}&id=${id}`)
    .then(response => response.text())
    .then(data => alert(data))
    .catch(error => console.error('Error:', error));
  closeAdminEdit();
  //To Refresh
  viewAdmin();
}

function showAdminEdit(index) {
  const question = questions[index];
  document.querySelector('#editQuestionNumber').value = `Question-${index+1}`;
  document.querySelector('#editQuestionText').value = question.question;
  
  document.querySelector('#editOptionA').value = question.options[0];
  document.querySelector('#editOptionB').value = question.options[1];
  
  const optionC = document.querySelector('#editOptionC');
  const optionD = document.querySelector('#editOptionD');

  optionC.value = question.options[2] || '';
  optionD.value = question.options[3] || '';

  // Hide options C and D if they are undefined
  optionC.style.display = question.options[2] ? 'block' : 'none';
  optionD.style.display = question.options[3] ? 'block' : 'none';

  document.querySelector('#editCorrect').value = question.correct;
  document.querySelector('#editBox').style.display = "flex";
}

function closeAdminEdit(){
  document.querySelector('#editBox').style.display = "none";
}

//DELETE
async function deleteQuestion(index) {
  const userConfirmation = confirm(`Are you sure you want to delete ${index+1} question?`);

  if(userConfirmation){
    const response = await fetch(`http://localhost:3000/Delete-Question?id=${index+1}`)
    .then(response => response.text())
    .then(data => alert(data))
    .catch(error => console.error('Error:', error));
  }
  //To Refresh
  viewAdmin();

}

//ADD
async function addQuestion(){
  const questionText = document.querySelector('#addQuestionText').value;
  const optionA = document.querySelector('#addOptionA').value;
  const optionB = document.querySelector('#addOptionB').value;
  const optionC = document.querySelector('#addOptionC').value;
  const optionD = document.querySelector('#addOptionD').value;
  const correctOption = document.querySelector('#addCorrect').value;
  
  // Ensure required fields are filled
  if (!questionText || !optionA || !optionB || !correctOption) {
    alert('Question, Option A, Option B, and Correct Answer are required.');
    return;
  }

  // Ensure correct answer matches one of the options
  if (![optionA, optionB, optionC, optionD].includes(correctOption)) {
    alert('Correct answer must match one of the provided options.');
    return;
  }
  // Filter Options
  const options = [optionA, optionB, optionC, optionD].filter(option => option !== '');
  const response = await fetch(`http://localhost:3000/Add-Question?question=${questionText}&options=${options}&correct=${correctOption}`)
    .then(response => response.text())
    .then(data => alert(data))
    .catch(error => console.error('Error:', error));
  closeAdminAdd();
  //To Refresh
  viewAdmin();
}

function showAdminAdd(){
  document.querySelector('#addBox').style.display = "flex";
}

function closeAdminAdd(){
  document.querySelector('#addBox').style.display = "none";
}
