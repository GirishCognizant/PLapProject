$(document).ready(function() {
  var mode = "home";

  // Event delegation for main container click
  $("#main").on("click", function(event) {
      // Prevent the main click event if a link is clicked
      if ($(event.target).is("a") || $(event.target).closest("a").length) {
          return;
      }

      if (mode == "home") {
          TweenMax.to($("#home"), 0.4, {
              y: -360
          });
          TweenMax.fromTo(
              $("#car"),
              0.4,
              {
                  y: 360,
                  autoAlpha: 1
              },
              {
                  y: 0
              }
          );
          mode = "car";
      } else if (mode == "car") {
          TweenMax.to($("#car"), 0.4, {
              y: -360
          });
          TweenMax.fromTo(
              $("#cardva"),
              0.4,
              {
                  y: 360,
                  autoAlpha: 1
              },
              {
                  y: 0
              }
          );
          mode = "cardva";
      } else if (mode == "cardva") {
          TweenMax.to($("#cardva"), 0.4, {
              y: -360
          });
          TweenMax.fromTo(
              $("#accountDashboard"),
              0.4,
              {
                  y: 360,
                  autoAlpha: 1
              },
              {
                  y: 0
              }
          );
          mode = "accountDashboard";
      } else if (mode == "accountDashboard") {
          TweenMax.to($("#accountDashboard"), 0.4, {
              y: -360
          });
          TweenMax.fromTo(
              $("#automation-zone"),
              0.4,
              {
                  y: 360,
                  autoAlpha: 1
              },
              {
                  y: 0
              }
          );
          mode = "automation-zone";
      }
       else if (mode == "automation-zone") {
          TweenMax.to($("#automation-zone"), 0.4, {
              y: -360
          });
          TweenMax.fromTo(
              $("#fuelup"),
              0.4,
              {
                  y: 360,
                  autoAlpha: 1
              },
              {
                  y: 0
              }
          );
          mode = "fuelup";
      } 
      else if (mode == "fuelup") {
        TweenMax.to($("#fuelup"), 0.4, {
            y: -360
        });
        TweenMax.fromTo(
            $("#testdrive"),
            0.4,
            {
                y: 360,
                autoAlpha: 1
            },
            {
                y: 0
            }
        );
        mode = "testdrive";
    } 
    else if (mode == "testdrive") {
      TweenMax.to($("#testdrive"), 0.4, {
          y: -360
      });
      TweenMax.fromTo(
          $("#kitearea"),
          0.4,
          {
              y: 360,
              autoAlpha: 1
          },
          {
              y: 0
          }
      );
      mode = "kitearea";
  } 
  else if (mode == "kitearea") {
    TweenMax.to($("#kitearea"), 0.4, {
        y: -360
    });
    TweenMax.fromTo(
        $("#sakthi"),
        0.4,
        {
            y: 360,
            autoAlpha: 1
        },
        {
            y: 0
        }
    );
    mode = "sakthi";
} 


      else if (mode == "sakthi") {
          TweenMax.to($("#home"), 0.2, {
              y: 0
          });
          TweenMax.fromTo(
              $("#sakthi"),
              0.2,
              {
                  y: 0,
                  autoAlpha: 1
              },
              {
                  y: 360
              }
          );
          mode = "home";
      }
  });

  $("#main").on("click", "a", function(event) {
    event.preventDefault(); // Prevent default anchor behavior
    event.stopPropagation(); // Stop event from bubbling up
    var targetUrl = $(this).attr("href"); // Get the target URL
    // Delay the navigation slightly to avoid conflict with animations
    setTimeout(function() {
        window.location.href = targetUrl;
    }, 300); // Adjust delay as needed
});
  // ----- On render -----
  makeRadial({
      el: $("#radial"),
      radials: 100
  });

  function makeRadial(options) {
      if (options && options.el) {
          var el = options.el;
          var radials = 60;
          if (options.radials) {
              radials = options.radials;
          }
          var degrees = 360 / radials;
          var i = 0;
          for (i = 0; i < radials / 2; i++) {
              var newTick = $('<div class="tick"></div>')
                  .css({
                      "-moz-transform": "rotate(" + i * degrees + "deg)"
                  })
                  .css({
                      "-webkit-transform": "rotate(" + i * degrees + "deg)"
                  })
                  .css({
                      transform: "rotate(" + i * degrees + "deg)"
                  });
              el.prepend(newTick);
          }
      }
  }
});

