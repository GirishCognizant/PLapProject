
        // function loadTable(url, containerId) {
        //     var xhr = new XMLHttpRequest();
        //     xhr.onreadystatechange = function() {
        //         if (xhr.readyState === 4 && xhr.status === 200) {
        //             document.getElementById(containerId).innerHTML = xhr.responseText;
        //         }
        //     };
        //     xhr.open('GET', url, true);
        //     xhr.send();
        // }

        // window.onload = function() {
        //     loadTable('table2.html', 'table-container-2');
        //     loadTable('table.html', 'table-container-3');
        // };
     // script.js
    