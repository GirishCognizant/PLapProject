document.addEventListener('DOMContentLoaded', function () {
    const page1Btn = document.getElementById('page1-btn');
    const page2Btn = document.getElementById('page2-btn');
    const page1 = document.getElementById('page1');
    const page2 = document.getElementById('page2');

    page1Btn.addEventListener('click', function () {
        page1.classList.add('active');
        page1.classList.remove('hidden');
        page2.classList.add('hidden');
        page2.classList.remove('active');
    });

    page2Btn.addEventListener('click', function () {
        page2.classList.add('active');
        page2.classList.remove('hidden');
        page1.classList.add('hidden');
        page1.classList.remove('active');
    });

    // Set initial state
    page1.classList.add('active');
});
