function validateForm() {
    var password = document.querySelector('#password').value;
    var repeatPassword = document.querySelector('#rePassword').value;


    if (password !== repeatPassword) {
      alert("Passwords do not match.");
      return false;
    }

      if (password.length < 8) {
        alert("Password must be at least 8 characters long.");
        return false;
      }
    
    return true;
}

async function register(){
  const validation = validateForm();
  if(validation){
      const name = document.querySelector('#associateName').value;;
      const id = document.querySelector('#associateId').value;
      const password = document.querySelector('#password').value;
      fetch(`http://localhost:3000/Register-Associate?name=${name}&id=${id}&password=${password}`)
      .then(response => response.text())
      .then(data => alert(data))
      .catch(error => console.error('Error:', error));
  }
}

