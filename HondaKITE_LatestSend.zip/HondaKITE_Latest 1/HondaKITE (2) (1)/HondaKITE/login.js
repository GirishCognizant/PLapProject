async function login() {
    event.preventDefault();
    const id = document.querySelector('#id').value;
    const password = document.querySelector('#psw').value;

    fetch(`http://localhost:3000/Login?&id=${id}&password=${password}`)
      .then(response => response.text())
      .then(data => alert(data))
      .catch(error => console.error('Error:', error));
    
}